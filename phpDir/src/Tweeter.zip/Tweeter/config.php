<?php

    $host = 'db';
    $dbname = 'blogdb';
    $dbuser = 'root';
    $dbpass = 'lionPass';

    // Check the MySQL connection status
    $conn = new mysqli($host, $dbuser, $dbpass, $dbname);


?>