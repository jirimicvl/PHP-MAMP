<?php
    // Shows all the data WORKS
    $query = "SELECT * FROM blogTable ORDER BY id DESC";
    $result = mysqli_query($conn, $query);

?>